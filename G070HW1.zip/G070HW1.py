#FIRST HOMEWORK OF BDC ON OUTLIERS DETECTION. GROUP 070, COMPOSED BY LOVO MANUEL, ALBERTO BRESSAN, MATTEO BALDONI


import sys  
import os
import random as rand
import math
from pyspark import SparkContext, SparkConf
import time

# Find the euclidean distance between two points, helper function
def euclidean_distance(point1, point2):
    x1, y1 = point1
    x2, y2 = point2
    distance = math.sqrt((x2 - x1)**2 + (y2 - y1)**2)
    return distance
 
 # Find the exact outliers using the euclidean distance
def ExactOutliers(points, D, M, K):
    start_time = time.time()
    count_close_point = 0
    count_outliers = 0
    outliers = []
    for i in range (len(points)):
        flag = True
        for j in range (len(points)):
            distance = euclidean_distance(points[i], points[j])
            if (distance < D):
                count_close_point = count_close_point+ 1
                if count_close_point > M: #In order to speed up the algorithm, if the algorithm see that there are more than M close point, skip to the next point
                    flag = False
                    break
        if flag and count_close_point <= M:
            count_outliers += 1
            outliers.append((points[i], count_close_point))
        count_close_point = 0
        
    outliers.sort(key=lambda x: x[1])
    print("Number of outliers:", count_outliers)
    for l in range(min(K, len(outliers))):
        print("Point: ", outliers[l][0])
    end_time = time.time()
    print("Running time of ExactOutliers:", (end_time - start_time)*1000, "ms")
    
# process each point and assign it to a grid cell
def process_point(point, lamb):
    x, y = point
    i = math.floor(x / lamb)
    j = math.floor(y / lamb)
    return ((i, j), 1)

# compute the number of points in the 3x3 and 7x7 neighborhood
def N3(point, lista):
    i, j = point[0]
    num = 0
    for k in range(-1, 2):
        for l in range(-1, 2):
            neighbor_key = (i + k, j + l)
            for key, value in lista:
                if key == neighbor_key:
                    num += value
                    break
    return num


def N7(point, lista):
    i, j = point[0]
    num = 0
    for k in range(-3, 4):
        for l in range(-3, 4):
            neighbor_key = (i + k, j + l)
            for key, value in lista:
                if key == neighbor_key:
                    num += value
                    break
    return num
    
def MRApproxOutlier(inputPointsRDD, D, M, K):

    start_time = time.time()

    lamb = D / (2 * math.sqrt(2))

    # Map phase: Process each point and assign it to a grid cell
    mapRDD = (inputPointsRDD.map(lambda point: process_point(point, lamb))
                            .reduceByKey(lambda x, y: x + y))

    # Filter non-empty cells
    non_empty_pairs = mapRDD.filter(lambda pair: pair[1] > 0)
    nep_list = non_empty_pairs.collect()

    pairsRDD = non_empty_pairs.map(lambda point: (point[0], point[1], N3(point, nep_list) ,N7(point, nep_list)))
    # Filter outliers and uncertain outliers
    outliers = pairsRDD.filter(lambda pair: pair[3] <= M)
    uncertain = pairsRDD.filter(lambda pair: pair[2]<=M and pair[3]>M)
    # Reduce phase: count the number of outliers and uncertain outliers
    outliers_num = (outliers.map(lambda pair: (1, pair[1]))
                            .reduceByKey(lambda x, y: x + y))

    uncertain_num = (uncertain.map(lambda pair: (1, pair[1]))
                             .reduceByKey(lambda x, y: x + y))

    outliers_list = outliers_num.collect()
    uncertain_list = uncertain_num.collect()

    if len(outliers_list) == 0:
        print("Number of outliers: 0")
    else:
        print("Number of outliers: ", outliers_list[0][1])

    if len(uncertain_list) == 0:
        print("Number of uncertain outliers: 0")
    else:
        print("Number of uncertain outliers: ", uncertain_list[0][1])
    # Sort RDD by the number of points in the cell
    output_rdd = pairsRDD.map(lambda pair: (pair[1],pair[0]))
    output_rdd = output_rdd.sortByKey()

    # Get the first K points with the largest number of close points
    firstK = output_rdd.take(K)
    print("The first K points with the largest number of close points:")
    for i in range (len(firstK)):
        print("Point: ",firstK[i][1], " Size: ",firstK[i][0])
    end_time = time.time()
    print("Running time of ApproxOutlier:", (end_time - start_time)*1000, "ms")

    


def main():
    assert len(sys.argv) == 6, "Usage: python main.py <input_file> <D> <M> <K> <L>"
    file_path = sys.argv[1]
    assert os.path.isfile(file_path), "File or folder not found"
    D = sys.argv[2]
    D = float(D)
    M = sys.argv[3]
    assert M.isdigit(), "M must be an integer"
    M = int(M)
    K = sys.argv[4]
    assert K.isdigit(), "K must be an integer"
    K = int(K)
    L = sys.argv[5]
    assert L.isdigit(), "L must be an integer"
    L = int(L)


    sc = SparkContext("local", "MRApproxOutlier")

    rawData = sc.textFile(file_path)
    inputPoints = rawData.map(lambda x: (float(x.split(",")[0]), float(x.split(",")[1]))).repartition(L)


    total_number = inputPoints.count()
    print("Number of points = ", total_number)

    if(total_number <= 200000):
        listOfPoints = inputPoints.collect()
        ExactOutliers(listOfPoints, D, M, K)
    
    MRApproxOutlier(inputPoints, D,M,K)

    sc.stop()

if __name__ == "__main__":
    main()
