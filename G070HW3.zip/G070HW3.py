#HOMEWORK 3 OF GROUP 070 COMPOSED BY BALDONI, LOVO AND BRESSAN

from pyspark.streaming import StreamingContext
from pyspark import StorageLevel
from pyspark import SparkConf, SparkContext
import threading
import sys
import random as rand
import math

n = -1  # To be set via command line

def process_batch(time, batch):
    global streamLength, hash_freq_table, S_res, S_sticky, phi, epsilon, delta, n #parameters that we need to update
   
    batch_items = batch.map(lambda s: (int(s), 1)).collect()  # Collecting the data in the batch as a list of tuples
    
    m = math.ceil(1 / phi)
    r = math.log(1 / (delta * phi)) / epsilon

    for key, count in batch_items:  # For each item in the batch

        streamLength[0] += 1  # Update stream length
        
        if streamLength[0] > n:  # If the stream is longer than n
            stopping_condition.set()
            return  # Ensure we stop processing immediately

        if key not in hash_freq_table:  
            hash_freq_table[key] = 0
        hash_freq_table[key] += count

        # Update reservoir sampling
        if len(S_res) < m:
            S_res.append(key)
        else:
            x = rand.random()
           
            if x <= m/(streamLength[0]):
                s = rand.randint(0, m-1)
                S_res[s] = key


        # Update sticky sampling
        if key not in S_sticky:
            if rand.random() <= (r / n):
                S_sticky[key] = 1
        else:
            S_sticky[key] += 1
        

if __name__ == '__main__':
    assert len(sys.argv) == 6, "6 parameters needed" #n, phi, epsilon, delta, port

    conf = SparkConf().setMaster("local[*]").setAppName("Ultimavers")

    sc = SparkContext(conf=conf)
    ssc = StreamingContext(sc, 0.01)  # Batch duration of 0.01 seconds
    ssc.sparkContext.setLogLevel("ERROR")

    stopping_condition = threading.Event()  # Semaphore, object which contains a boolean

    # INPUT READING
    n = int(sys.argv[1])
    phi = float(sys.argv[2])
    epsilon = float(sys.argv[3])
    delta = float(sys.argv[4])
    portExp = int(sys.argv[5])

    # DEFINING THE REQUIRED DATA STRUCTURES TO MAINTAIN THE STATE OF THE STREAM
    streamLength = [0]  # Stream length (an array to be passed by reference)
    hash_freq_table = {}  # Hash Table for frequent items
    S_res = []  # Structure for reservoir sampling
    S_sticky = {}  # Structure for sticky sampling

    # CODE TO PROCESS AN UNBOUNDED STREAM OF DATA IN BATCHES
    stream = ssc.socketTextStream("algo.dei.unipd.it", portExp, StorageLevel.MEMORY_AND_DISK)
    stream.foreachRDD(lambda time, batch: process_batch(time, batch))

    # MANAGING STREAMING SPARK CONTEXT
    print("Starting streaming engine")
    ssc.start()
    print("Waiting for shutdown condition")
    stopping_condition.wait()
    print("Stopping the streaming engine")
    ssc.stop(False, False)
    print("Streaming engine stopped")

    # COMPUTE AND PRINT FINAL STATISTICS
    print('INPUT PROPERTIES')
    print('n =', n, 'phi =', phi, 'epsilon =', epsilon, 'delta =', delta, 'port =', portExp)

    # Compute and print the true frequent items
    print('EXACT ALGORITHM')
    print("Number of items in the data structure =", len(hash_freq_table))
    filtered_keys = [key for key, value in hash_freq_table.items() if value >= phi * n]
    sorted_filtered_keys = sorted(filtered_keys)

    print('Number of true frequent items =', len(filtered_keys))
    print('True frequent items:')
    for key in sorted_filtered_keys:
        print(key)

    # Compute and print reservoir sampling results
    print('RESERVOIR SAMPLING')
    print('Size m of the sample =', len(S_res))
    distinct_keys = set(S_res)
    sorted_res = sorted(distinct_keys)
    print('Number of estimated frequent items =', len(distinct_keys))
    print('Estimated frequent items:')
    for key in sorted_res:
        if key in filtered_keys:
            print(key ,"+")
        else:
            print(key ,"-")
        

    # Compute and print sticky sampling results
    print('STICKY SAMPLING')
    print('Number of items in the Hash Table =', len(S_sticky))
    filtered_sticky_keys = [key for key, value in S_sticky.items() if value >= (phi - epsilon) * n]
    sorted_sticky = sorted(filtered_sticky_keys)
    print('Number of estimated frequent items =', len(filtered_sticky_keys))
    print('Estimated frequent items:')
    for key in sorted_sticky:
        if key in filtered_keys:
            print(key ,"+")
        else:
            print(key ,"-")
