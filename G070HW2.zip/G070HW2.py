#SECOND HOMEWORK OF BDC ON OUTLIERS DETECTION. GROUP 070, COMPOSED BY LOVO MANUEL, ALBERTO BRESSAN, MATTEO BALDONI


import sys  
import os
import random as rand
import math
from pyspark import SparkContext, SparkConf, StorageLevel
import time
from math import sqrt
import numpy as np
    
conf = SparkConf().setAppName('MRApproxOutlier')
conf.set("spark.locality.wait", "0s")
sc = SparkContext(conf=conf)

def euclidean_distance(p1, p2):
    return sqrt(sum((x - y) ** 2 for x, y in zip(p1, p2)))


def SequentialFFT(P, K):

    '''In this function, we implement the sequential FFT algorithm to find the k centers of the dataset P.
    The input P is supposed to be a list, so we need to convert it in the case we apply this function on an RDD (iterator).
    Then we have implemented a first version of SequentialFFT using list/dictionaries but we have discovered that numpy handles in a better way some of the operations.'''
    points_1 = list(P)

    points = np.array(points_1) #Conversion list to numpy array

    C = [rand.choice(points)] #First center is a random point in the dataset

    min_distances = np.full(len(points), np.inf) #Inizialization of array with min distances, set to infinity s.t. every distance is less than this

    min_distances = np.linalg.norm(points - C[0], axis=1) # Update distances for the first center, numpy array of dimension n where are contained distances from each point to the first center

    for center_index in range(1, K):
        #Here we found the farthest point and we add it as new center
        farthest_point_index = np.argmax(min_distances)
        new_center = points[farthest_point_index]
        C.append(new_center)
        
        # Here we update min distances array
        distances_to_new_center = np.linalg.norm(points - new_center, axis=1)
        min_distances = np.minimum(min_distances, distances_to_new_center)

    return C



def find_radius(point, C): #helper function in order to optimize computation of Round3
    '''Also here we've used numpy array in order to benefit from it's vectorized operations'''
    point_array = np.array(point)
    distances = np.linalg.norm(C - point_array, axis=1)
    return np.min(distances)
    
    

def MRFFT(P, K):
    '''MapReduce FFT algorithm exploiting partitions of Spark'''

    start_time_1 = time.time()
    Red_R1 = (P.mapPartitions(lambda partition: SequentialFFT(partition, K))).persist(StorageLevel.MEMORY_AND_DISK) # Due to the fact that mapPartitions is a lazy function and in order to avoid that computation is done after, we do a sort of cache op, followed by a dumb operation
    Red_R1.count()
    end_time_1 = time.time()

    coreset = Red_R1.collect()
    start_time_2 = time.time()
    C = SequentialFFT(coreset, K)
    end_time_2 = time.time()

    C_broadcast = sc.broadcast(C)
    C_local = C_broadcast.value 
    C_array = np.array(C_local)
    start_time_3 = time.time()
    R = P.map(lambda point: find_radius(point, C_array)).reduce(max)
    end_time_3 = time.time()
    print("Running time of MRFFT Round 1 =", round((end_time_1 - start_time_1)*1000), "ms") # integer running time of round 1 as in the output format
    print("Running time of MRFFT Round 2 =", round((end_time_2 - start_time_2)*1000), "ms") # integer running time of round 2 as in the output format
    print("Running time of MRFFT Round 3 =", round((end_time_3 - start_time_3)*1000), "ms") # integer running time of round 3 as in the output format
    return float('{:.8f}'.format(R)) # Radius value with 8 digits after the comma as in the output format


# process each point and assign it to a grid cell
def process_point(point, lamb):
    x, y = point
    i = math.floor(x / lamb)
    j = math.floor(y / lamb)
    return ((i, j), 1)

# compute the number of points in the 3x3 and 7x7 neighborhood
def N3(point, lista):
    i, j = point[0]
    num = 0
    for k in range(-1, 2):
        for l in range(-1, 2):
            neighbor_key = (i + k, j + l)
            for key, value in lista:
                if key == neighbor_key:
                    num += value
                    break
    return num


def N7(point, lista):
    i, j = point[0]
    num = 0
    for k in range(-3, 4):
        for l in range(-3, 4):
            neighbor_key = (i + k, j + l)
            for key, value in lista:
                if key == neighbor_key:
                    num += value
                    break
    return num
    
def MRApproxOutlier(inputPointsRDD, D, M):

    start_time = time.time()

    lamb = D / (2 * math.sqrt(2))

    # Map phase: Process each point and assign it to a grid cell
    mapRDD = (inputPointsRDD.map(lambda point: process_point(point, lamb))
                            .reduceByKey(lambda x, y: x + y))

    # Filter non-empty cells
    non_empty_pairs = mapRDD.filter(lambda pair: pair[1] > 0)
    nep_list = non_empty_pairs.collect()

    pairsRDD = non_empty_pairs.map(lambda point: (point[0], point[1], N3(point, nep_list) ,N7(point, nep_list)))
    # Filter outliers and uncertain outliers
    outliers = pairsRDD.filter(lambda pair: pair[3] <= M)
    uncertain = pairsRDD.filter(lambda pair: pair[2]<=M and pair[3]>M)
    # Reduce phase: count the number of outliers and uncertain outliers
    outliers_num = (outliers.map(lambda pair: (1, pair[1]))
                            .reduceByKey(lambda x, y: x + y))

    uncertain_num = (uncertain.map(lambda pair: (1, pair[1]))
                             .reduceByKey(lambda x, y: x + y))

    outliers_list = outliers_num.collect()
    uncertain_list = uncertain_num.collect()

    if len(outliers_list) == 0:
        print("Number of sure outliers = 0")
    else:
        print("Number of sure outliers =", outliers_list[0][1])

    if len(uncertain_list) == 0:
        print("Number of uncertain points = 0")
    else:
        print("Number of uncertain points =", uncertain_list[0][1])
    end_time = time.time()
    print("Running time of MRApproxOutlier =", round((end_time - start_time)*1000), "ms") #integer running time of MRApproxOutlier as in the output format

    


def main():
    assert len(sys.argv) == 5, "Usage: python main.py <input_file> <M> <K> <L>"
    file_path = sys.argv[1]
    
    M = sys.argv[2]
    assert M.isdigit(), "M must be an integer"
    M = int(M)
    K = sys.argv[3]
    assert K.isdigit(), "K must be an integer"
    K = int(K)
    L = sys.argv[4]
    assert L.isdigit(), "L must be an integer"
    L = int(L)
    print(file_path, "M=", M, "K=", K, "L=", L)

    rawData = sc.textFile(file_path)
    inputPoints = rawData.map(lambda x: (float(x.split(",")[0]), float(x.split(",")[1]))).repartition(L)

    total_number = inputPoints.count()
    print("Number of points =", total_number)

    D = MRFFT(inputPoints, K)

    print("Radius =", D)

    MRApproxOutlier(inputPoints,D,M)

    


    sc.stop()

if __name__ == "__main__":
    main()